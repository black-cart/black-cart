@extends($templatePathAdmin.'layout')

@section('main')
    {{-- content --}}
@endsection

@push('styles')
      {{-- style css --}}
@endpush

@push('scripts')
      {{-- script --}}
@endpush
