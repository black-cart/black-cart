<?php
    $this->loadTranslationsFrom(__DIR__.'/Lang', 'Plugins/Other/ImportProduct');
    $this->loadViewsFrom(__DIR__.'/Views', 'Plugins/Other/ImportProduct');